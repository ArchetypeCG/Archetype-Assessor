ARCHETYPE COACHING GROUP — GMAIL SIGNATURE

The banner uses the approved navy, blue and cyan palette.
Company: https://archetypecoachinggroup.com/
Platform: https://www.archetype-portfolio.com/
Demonstration enquiries: https://archetypecoachinggroup.com/

SET UP IN GMAIL ON A COMPUTER
1. Download and unzip the signature pack.
2. Open Archetype-Signature.html in Chrome or another browser.
3. Click “Copy signature text”. This copies the formatted text, not HTML code.
4. In Gmail, click the settings cog → See all settings → General.
5. Scroll to Signature → Create new. Call it “Archetype”.
6. Click inside the signature editor and paste the copied text.
7. Put your cursor on a new line below it. Click Insert image and upload Archetype-Banner.jpg from the pack.
8. Select the image and choose a size that fits comfortably in the email; Medium is a useful starting point.
9. To make the banner clickable, select it and use the Link button (or Ctrl+K / Command+K), then enter https://archetypecoachinggroup.com/.
10. Under Signature defaults, select “Archetype” for new emails and, if wanted, replies/forwards.
11. Scroll to the bottom and click Save Changes.
12. Start a new message and send yourself a test. Check the result on desktop and mobile.

IMPORTANT
Upload the image in Gmail itself. Copying an image from a local HTML file can leave a broken image for recipients.
Copy the rendered signature; do not paste the HTML source into Gmail.
Keep the written company details as well as the banner so they remain readable if a recipient blocks images.
If your Gmail account does not offer an Upload tab, insert an accessible image URL or follow your organisation’s Google Workspace image policy.
Gmail’s mobile signature settings are separate; set up the formatted signature on a computer first.

PERSONAL DETAILS
Prepared for Lee Horsley, Founder & Director.
Email: lee@archetypecoachinggroup.com
Telephone: 07772 413682 (click-to-call +447772413682).
